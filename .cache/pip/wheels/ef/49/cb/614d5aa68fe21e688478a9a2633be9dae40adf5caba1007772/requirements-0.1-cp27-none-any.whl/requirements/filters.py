
def repo_type(repo):
    types = ''
    if repo.private is False:
        types += 'public'
        # fork is public only
        if repo.fork is True:
            types += ' fork'  # whitespace intended
    else:
        types += 'private'
    return types


def count_repos(repos):
    """Counts items from dict of lists"""
    return sum(map(len, repos.values()))
