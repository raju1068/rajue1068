import os

from flask import Flask
from raven.contrib.flask import Sentry

from requirements.filters import repo_type, count_repos

app = Flask(__name__)
app.config.from_object('requirements.settings')
app.jinja_env.filters['repo_type'] = repo_type
app.jinja_env.filters['count_repos'] = count_repos

sentry = Sentry(app, dsn=os.environ.get('SENTRY_DSN'))
sentry.init_app(app)

from requirements.views import *
