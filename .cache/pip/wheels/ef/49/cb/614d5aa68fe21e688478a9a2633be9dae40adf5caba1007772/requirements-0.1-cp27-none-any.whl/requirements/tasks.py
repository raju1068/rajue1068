import base64
import logging

from flask import session
from requirements import app
from requirements.github import github
from requirements.models import db, Repo, Package, User
from requirements.utils import parse

logging.basicConfig()


def process_requirements(repo, github_token):
    with app.test_request_context():
        # TODO: hacky, needs good comment
        session['github_token'] = github_token

        token = github_token[0]
        user = User.query.filter_by(github_access_token=token).first()
        # TODO: log this event
        if not user:
            return False

        requirement_file = '/repos/{0}/{1}/contents/requirements.txt'
        content = github.get(requirement_file.format(repo.owner, repo.name))

        # not found so good bye
        if content._resp.getcode() == 404:
            r = Repo.query.get(repo.id)
            r.log = 'requirements.txt not found.'
            db.session.commit()
            return False

        content = content.data['content']
        content = base64.b64decode(content)

        reqs = parse(content)
        for x in reqs:
            kwargs = {
                'repo_id': repo.id,
                'name': x.project_name,
                'version': x.specs[0][1],
                'version_pypi': '',
            }
            p = Package(**kwargs)
            db.session.add(p)
            db.session.commit()
        return True
