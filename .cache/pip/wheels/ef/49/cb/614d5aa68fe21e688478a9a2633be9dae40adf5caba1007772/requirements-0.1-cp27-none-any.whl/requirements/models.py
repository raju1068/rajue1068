from apscheduler.scheduler import Scheduler
from flask.ext.sqlalchemy import SQLAlchemy

from requirements import app

db = SQLAlchemy(app)
db.init_app(app)

member_org_map = db.Table(
    'member_org_map',
    db.Column(
        'member_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),
    db.Column(
        'org_id', db.Integer, db.ForeignKey('user.id'), primary_key=True))

scheduler = Scheduler()
scheduler.start()


class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String)
    github_access_token = db.Column(db.String)
    is_member = db.Column(db.Boolean)
    repos = db.relationship('Repo',
                            backref=db.backref('user', lazy='joined'),
                            lazy='dynamic')
    orgs = db.relationship('User',
                           secondary=member_org_map,
                           primaryjoin=id==member_org_map.c.member_id,
                           secondaryjoin=id==member_org_map.c.org_id,
                           backref='members', lazy='dynamic')

    def __init__(self, username, github_access_token):
        self.username = username
        self.github_access_token = github_access_token

    def __repr__(self):
        org = 'Member' if self.is_member else 'Organisation'
        return '<User {0}, ({1})>'.format(self.username, org)


class Repo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    name = db.Column(db.String)  # TODO: needs to be unique
    url = db.Column(db.String)
    owner = db.Column(db.String)
    created_date = db.Column(db.DateTime)
    updated_date = db.Column(db.DateTime)
    public = db.Column(db.Boolean)
    private = db.Column(db.Boolean)
    fork = db.Column(db.Boolean)
    last_sync_date = db.Column(db.DateTime)
    log = db.Column(db.String)

    packages = db.relationship(
        'Package',
        backref=db.backref('repo', lazy='joined'),
        lazy='dynamic')

    def __repr__(self):
        last_sync = self.last_sync_date if self.last_sync_date else 'N/A'
        return '<Repo {} (last synced: {})>'.format(self.name, last_sync)


class Package(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    repo_id = db.Column(db.Integer, db.ForeignKey('repo.id'))
    name = db.Column(db.String)
    version = db.Column(db.String)

    def __repr__(self):
        return '<Package {0} v{1}>'.format(self.name, self.version)


class PypiPackage(db.Model):
    """Stores latest package versions available on PyPI."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, unique=True)
    version = db.Column(db.String)  # this might be anything

    def __repr__(self):
        return '<PypiPackage {0} v{1}>'.format(self.name, self.version)

    # tasks:
    # get_newest_packages -> create -> every 2h - settings?
    # get_latest_updated -> update -> every 2h - settings?
